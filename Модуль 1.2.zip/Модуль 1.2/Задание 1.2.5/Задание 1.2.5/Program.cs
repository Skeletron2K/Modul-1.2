﻿using System;
using System.Collections.Generic;

namespace Задание_1._2._5
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Программа для работы с символьными массивами");
            Console.WriteLine("Создание массива случайных букв и выделение согласных");

            // Строки с буквами русского алфавита (строчные и заглавные)
            string russianAlphabetLower = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя";
            string russianAlphabetUpper = "АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";
            string russianAlphabet = russianAlphabetLower + russianAlphabetUpper;

            // Согласные буквы (строчные и заглавные)
            string consonantsLower = "бвгджзйклмнпрстфхцчшщ";
            string consonantsUpper = "БВГДЖЗЙКЛМНПРСТФХЦЧШЩ";
            string consonants = consonantsLower + consonantsUpper;

            while (true)
            {
                Console.Write("\nВведите количество элементов K (или 'q' для выхода): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "q")
                {
                    Console.WriteLine("Программа завершена. До свидания!");
                    break;
                }

                if (int.TryParse(input, out int k) && k > 0)
                {
                    // Создаем исходный массив
                    char[] originalArray = CreateRandomCharArray(k, russianAlphabet);

                    // Создаем массив согласных
                    char[] consonantsArray = ExtractConsonants(originalArray, consonants);

                    // Выводим результаты
                    Console.WriteLine("\nИсходный массив:");
                    PrintCharArray(originalArray);

                    Console.WriteLine("\nМассив согласных букв:");
                    PrintCharArray(consonantsArray);

                    // Дополнительная информация
                    Console.WriteLine($"\nСтатистика:");
                    Console.WriteLine($"Всего элементов: {originalArray.Length}");
                    Console.WriteLine($"Согласных букв: {consonantsArray.Length}");
                    Console.WriteLine($"Гласных букв: {CountVowels(originalArray, consonants)}");
                    Console.WriteLine($"Других символов: {originalArray.Length - consonantsArray.Length - CountVowels(originalArray, consonants)}");
                }
                else
                {
                    Console.WriteLine("Ошибка: K должно быть положительным целым числом.");
                }
            }

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        // Метод для создания массива случайных букв русского алфавита
        static char[] CreateRandomCharArray(int k, string alphabet)
        {
            Random random = new Random();
            char[] array = new char[k];

            for (int i = 0; i < k; i++)
            {
                int randomIndex = random.Next(0, alphabet.Length);
                array[i] = alphabet[randomIndex];
            }

            return array;
        }

        // Метод для извлечения согласных букв из массива
        static char[] ExtractConsonants(char[] array, string consonants)
        {
            List<char> consonantsList = new List<char>();

            foreach (char c in array)
            {
                if (consonants.Contains(c.ToString()))
                {
                    consonantsList.Add(c);
                }
            }

            return consonantsList.ToArray();
        }

        // Метод для подсчета гласных букв
        static int CountVowels(char[] array, string consonants)
        {
            int count = 0;
            string russianLetters = "абвгдеёжзийклмнопрстуфхцчшщъыьэюяАБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ";

            foreach (char c in array)
            {
                if (russianLetters.Contains(c.ToString()) && !consonants.Contains(c.ToString()))
                {
                    count++;
                }
            }

            return count;
        }

        // Метод для вывода символьного массива
        static void PrintCharArray(char[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write($"{array[i]} ");
                if ((i + 1) % 15 == 0)
                    Console.WriteLine();
            }

            if (array.Length % 15 != 0)
                Console.WriteLine();
        }
    }
}
