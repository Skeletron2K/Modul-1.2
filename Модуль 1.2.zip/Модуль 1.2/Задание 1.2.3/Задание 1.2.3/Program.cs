﻿using System;
using System.Collections.Generic;

namespace Задание_1._2._3
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Программа для вычисления K простых чисел");

            while (true)
            {
                Console.Write("\nВведите количество простых чисел K (или 'q' для выхода): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "q")
                {
                    Console.WriteLine("Программа завершена. До свидания!");
                    break;
                }

                if (int.TryParse(input, out int k) && k > 0)
                {
                    List<int> primes = GeneratePrimes(k);

                    Console.WriteLine($"\nПервые {k} простых чисел:");
                    PrintPrimes(primes);
                }
                else
                {
                    Console.WriteLine("Ошибка: введите положительное целое число.");
                }
            }

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        // Метод для генерации K простых чисел
        static List<int> GeneratePrimes(int k)
        {
            List<int> primes = new List<int>();

            if (k <= 0) return primes;

            // Первое простое число
            primes.Add(2);

            // Если нужно только одно простое число
            if (k == 1) return primes;

            int number = 3; // Начинаем проверять с 3

            while (primes.Count < k)
            {
                if (IsPrime(number))
                {
                    primes.Add(number);
                }
                number += 2; // Проверяем только нечетные числа (кроме 2)
            }

            return primes;
        }

        // Метод для проверки, является ли число простым
        static bool IsPrime(int n)
        {
            if (n < 2) return false;
            if (n == 2) return true;
            if (n % 2 == 0) return false;

            // Проверяем делимость на нечетные числа до квадратного корня из n
            int limit = (int)Math.Sqrt(n);
            for (int i = 3; i <= limit; i += 2)
            {
                if (n % i == 0)
                    return false;
            }

            return true;
        }

        // Метод для вывода простых чисел по 10 на строку
        static void PrintPrimes(List<int> primes)
        {
            for (int i = 0; i < primes.Count; i++)
            {
                Console.Write($"{primes[i],6}");

                // Переход на новую строку после каждых 10 чисел
                if ((i + 1) % 10 == 0)
                    Console.WriteLine();
            }

            // Если последняя строка не полная, переводим строку
            if (primes.Count % 10 != 0)
                Console.WriteLine();
        }
    }
}
