﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Задание_1._2._4
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Программа для работы с массивом");
            Console.WriteLine("Поиск минимального и максимального элементов и вывод значений между ними");

            while (true)
            {
                Console.Write("\nВведите количество элементов K (или 'q' для выхода): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "q")
                {
                    Console.WriteLine("Программа завершена. До свидания!");
                    break;
                }

                if (int.TryParse(input, out int k) && k > 0)
                {
                    Console.Write("Введите нижнюю границу A: ");
                    if (!int.TryParse(Console.ReadLine(), out int a))
                    {
                        Console.WriteLine("Ошибка: введите целое число для A.");
                        continue;
                    }

                    Console.Write("Введите верхнюю границу B: ");
                    if (!int.TryParse(Console.ReadLine(), out int b))
                    {
                        Console.WriteLine("Ошибка: введите целое число для B.");
                        continue;
                    }

                    if (b <= a)
                    {
                        Console.WriteLine("Ошибка: B должно быть больше A.");
                        continue;
                    }

                    // Создаем и заполняем массив
                    int[] array = CreateRandomArray(k, a, b);

                    // Выводим исходный массив
                    Console.WriteLine("\nИсходный массив:");
                    PrintArray(array);

                    // Находим индексы минимального и максимального элементов
                    FindMinMaxIndices(array, out int minIndex, out int maxIndex);

                    // Выводим элементы между minIndex и maxIndex (включая их)
                    Console.WriteLine("\nЭлементы между минимальным и максимальным (включая их):");
                    PrintRange(array, minIndex, maxIndex);
                }
                else
                {
                    Console.WriteLine("Ошибка: K должно быть положительным целым числом.");
                }
            }

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        // Метод для создания массива со случайными числами в диапазоне [A, B)
        static int[] CreateRandomArray(int k, int a, int b)
        {
            Random random = new Random();
            int[] array = new int[k];

            for (int i = 0; i < k; i++)
            {
                array[i] = random.Next(a, b); // [A, B) - включая A, не включая B
            }

            return array;
        }

        // Метод для поиска индексов минимального и максимального элементов
        static void FindMinMaxIndices(int[] array, out int minIndex, out int maxIndex)
        {
            minIndex = 0;
            maxIndex = 0;

            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] < array[minIndex])
                {
                    minIndex = i;
                }

                if (array[i] > array[maxIndex])
                {
                    maxIndex = i;
                }
            }

            Console.WriteLine($"\nМинимальный элемент: array[{minIndex}] = {array[minIndex]}");
            Console.WriteLine($"Максимальный элемент: array[{maxIndex}] = {array[maxIndex]}");
        }

        // Метод для вывода элементов массива между двумя индексами (включая их)
        static void PrintRange(int[] array, int index1, int index2)
        {
            // Определяем начальный и конечный индексы
            int start = Math.Min(index1, index2);
            int end = Math.Max(index1, index2);

            Console.Write($"Индексы от {start} до {end}: ");
            for (int i = start; i <= end; i++)
            {
                Console.Write($"{array[i]} ");
            }
            Console.WriteLine();

            // Дополнительная информация
            Console.WriteLine($"Количество элементов в диапазоне: {end - start + 1}");
        }

        // Метод для вывода всего массива
        static void PrintArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write($"{array[i],4}");
                if ((i + 1) % 10 == 0)
                    Console.WriteLine();
            }

            if (array.Length % 10 != 0)
                Console.WriteLine();
        }
    }
}
