﻿using System;

namespace Задание_1._2._2
{
    class Program
    {
        static void Main()
        {
            // Инициализация массива (с несколькими одинаковыми максимальными значениями)
            int[] array = { 5, 23, 8, 23, 15, 7, 18, 3, 21, 23 };

            Console.WriteLine("Исходный массив:");
            PrintArray(array);

            // Находим максимальное значение
            int maxValue = array[0];
            for (int i = 1; i < array.Length; i++)
            {
                if (array[i] > maxValue)
                {
                    maxValue = array[i];
                }
            }

            Console.WriteLine($"\nМаксимальный элемент: {maxValue}");

            // Ввод нового значения
            Console.Write("\nВведите целое число для замены максимального элемента: ");
            string input = Console.ReadLine();

            if (int.TryParse(input, out int newValue))
            {
                // Заменяем все максимальные элементы
                int count = 0;
                for (int i = 0; i < array.Length; i++)
                {
                    if (array[i] == maxValue)
                    {
                        array[i] = newValue;
                        count++;
                    }
                }

                Console.WriteLine("\nМассив после замены:");
                PrintArray(array);
                Console.WriteLine($"Заменено {count} максимальных элементов на значение: {newValue}");
            }
            else
            {
                Console.WriteLine("Ошибка: введено не целое число.");
            }

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        // Метод для вывода массива
        static void PrintArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write($"{array[i],3} ");
            }
            Console.WriteLine();
        }
    }
}