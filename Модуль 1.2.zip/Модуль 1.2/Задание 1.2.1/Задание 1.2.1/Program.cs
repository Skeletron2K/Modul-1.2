﻿using System;

namespace Задание_1._2._1
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Нормировка массива");
            Console.WriteLine("Программа делит все элементы массива на максимальный по модулю элемент");

            while (true)
            {
                Console.Write("\nВведите размер массива N (или 'q' для выхода): ");
                string input = Console.ReadLine();

                if (input.ToLower() == "q")
                {
                    Console.WriteLine("Программа завершена. До свидания!");
                    break;
                }

                if (int.TryParse(input, out int n) && n > 0)
                {
                    double[] array = new double[n];

                    Console.WriteLine($"Введите {n} элементов массива:");
                    for (int i = 0; i < n; i++)
                    {
                        Console.Write($"Элемент [{i}]: ");
                        if (double.TryParse(Console.ReadLine(), out double value))
                            array[i] = value;
                        else
                        {
                            Console.WriteLine("Ошибка: введено не число. Повторите ввод.");
                            i--;
                        }
                    }

                    Console.WriteLine("\nИсходный массив:");
                    for (int i = 0; i < n; i++)
                    {
                        Console.Write($"{array[i]:F4} ");
                        if ((i + 1) % 5 == 0) Console.WriteLine();
                    }
                    Console.WriteLine();

                    double maxAbs = 0;
                    for (int i = 0; i < n; i++)
                    {
                        double absValue = Math.Abs(array[i]);
                        if (absValue > maxAbs) maxAbs = absValue;
                    }

                    if (maxAbs == 0)
                    {
                        Console.WriteLine("Максимальный по модулю элемент равен 0. Нормировка невозможна.");
                    }
                    else
                    {
                        Console.WriteLine($"Максимальный по модулю элемент: {maxAbs:F4}");
                        Console.WriteLine("Нормированный массив:");

                        for (int i = 0; i < n; i++)
                        {
                            Console.Write($"{(array[i] / maxAbs):F6} ");
                            if ((i + 1) % 5 == 0) Console.WriteLine();
                        }
                        Console.WriteLine();
                    }
                }
                else
                {
                    Console.WriteLine("Ошибка: размер массива должен быть положительным целым числом.");
                }
            }

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
}