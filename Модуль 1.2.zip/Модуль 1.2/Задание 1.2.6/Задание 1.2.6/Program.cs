﻿using System;

namespace Задание_1._2._6
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Программа для работы с вещественным массивом");
            Console.WriteLine("Создание массива индексов, упорядоченных по возрастанию значений элементов");

            // Создаем и заполняем массив из 10 элементов
            double[] array = CreateRandomArray(10, -10, 10);

            // Выводим исходный массив
            Console.WriteLine("\nИсходный массив:");
            PrintArray(array);

            // Создаем массив индексов, упорядоченных по возрастанию значений элементов
            int[] sortedIndices = CreateSortedIndices(array);

            // Выводим массив индексов
            Console.WriteLine("\nМассив индексов, упорядоченных по возрастанию значений:");
            PrintIndices(sortedIndices);

            // Выводим значения элементов в порядке возрастания (для проверки)
            Console.WriteLine("\nЭлементы массива в порядке возрастания:");
            PrintSortedValues(array, sortedIndices);

            // Дополнительная информация
            Console.WriteLine($"\nМинимальный элемент: array[{sortedIndices[0]}] = {array[sortedIndices[0]]:F4}");
            Console.WriteLine($"Максимальный элемент: array[{sortedIndices[sortedIndices.Length - 1]}] = {array[sortedIndices[sortedIndices.Length - 1]]:F4}");

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }

        // Метод для создания массива со случайными вещественными числами в диапазоне [min, max)
        static double[] CreateRandomArray(int size, double min, double max)
        {
            Random random = new Random();
            double[] array = new double[size];

            for (int i = 0; i < size; i++)
            {
                // Генерируем случайное вещественное число в заданном диапазоне
                array[i] = min + (random.NextDouble() * (max - min));
            }

            return array;
        }

        // Метод для создания массива индексов, упорядоченных по возрастанию значений элементов
        static int[] CreateSortedIndices(double[] array)
        {
            // Создаем массив индексов [0, 1, 2, ..., n-1]
            int[] indices = new int[array.Length];
            for (int i = 0; i < indices.Length; i++)
            {
                indices[i] = i;
            }

            // Сортируем индексы по значениям элементов массива
            Array.Sort(indices, (a, b) => array[a].CompareTo(array[b]));

            return indices;
        }

        // Метод для вывода массива индексов
        static void PrintIndices(int[] indices)
        {
            for (int i = 0; i < indices.Length; i++)
            {
                Console.Write($"{indices[i],3}");
                if ((i + 1) % 10 == 0)
                    Console.WriteLine();
            }

            if (indices.Length % 10 != 0)
                Console.WriteLine();
        }

        // Метод для вывода значений массива в порядке возрастания (для проверки)
        static void PrintSortedValues(double[] array, int[] sortedIndices)
        {
            for (int i = 0; i < sortedIndices.Length; i++)
            {
                int index = sortedIndices[i];
                Console.Write($"{array[index]:F4} ");
                if ((i + 1) % 5 == 0)
                    Console.WriteLine();
            }

            if (sortedIndices.Length % 5 != 0)
                Console.WriteLine();
        }

        // Метод для вывода вещественного массива
        static void PrintArray(double[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write($"{array[i],8:F4}");
                if ((i + 1) % 5 == 0)
                    Console.WriteLine();
            }

            if (array.Length % 5 != 0)
                Console.WriteLine();
        }
    }
}
